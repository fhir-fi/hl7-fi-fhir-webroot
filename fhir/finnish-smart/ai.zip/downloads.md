# Downloads - Finnish Implementation Guide for SMART App Launch v2.0.0

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

Download automatically generated assets for offline use.

### This Implementation Guide

This full IG as a single package:

* [full-ig.zip](full-ig.zip)

The ImplementationGuide resource:

* Javascript Object Notation (JSON) format: [ImplementationGuide-hl7.fhir.fi.smart.json](ImplementationGuide-hl7.fhir.fi.smart.json)
* Terse RDF Triple Language (TTL) format: [ImplementationGuide-hl7.fhir.fi.smart.ttl](ImplementationGuide-hl7.fhir.fi.smart.ttl)
* Extensible Markup Language (XML) format: [ImplementationGuide-hl7.fhir.fi.smart.xml](ImplementationGuide-hl7.fhir.fi.smart.xml)

### NPM Package

Profiles, valuesets, examples, and other assets used in this IG in npm format:

* FHIR version R4 [package.tgz](package.tgz)
* FHIR version R4B [package.r4b.tgz](package.r4b.tgz)

### Definitions

Definitions included in this IG in different file formats:

* Javascript Object Notation (JSON) format: [definitions.json.zip](definitions.json.zip)
* Terse RDF Triple Language (TTL) format: [definitions.ttl.zip](definitions.ttl.zip)
* Extensible Markup Language (XML) format: [definitions.xml.zip](definitions.xml.zip)

### Examples

All example files included in this IG:

* JSON [examples.json.zip](examples.json.zip)
* TTL [examples.ttl.zip](examples.ttl.zip)
* XML [examples.xml.zip](examples.xml.zip)

### FHIR Tools

For generic FHIR tools, frameworks, and supported programming languages, see [https://hl7.org/fhir/downloads.html](https://hl7.org/fhir/downloads.html)

